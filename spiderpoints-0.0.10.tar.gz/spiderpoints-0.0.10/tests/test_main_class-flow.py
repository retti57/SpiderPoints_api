def test_main_creates_kml_and_gpx_files():
    import pathlib
    import os

    from spiderpoints.spiderpoints import SpiderPoints
    str_float = "52.734683, 18.369269"
    dstnce = 5
    occ = 7
    SpiderPoints(str_float, dstnce, occ).create_kml_gpx()

    for fpath, _, _ in os.walk(pathlib.Path.cwd().parent):
        if 'kml' in fpath.lower():
            assert True
        elif 'gpx' in fpath.lower():
            assert True
